<div id="top"></div>

<h3 align="center">Kiyoko's Mighty Omega Macro</h3>

  <p align="center">
    Macro for mighty omega using Autohotkey!
    <br />
    <a href="https://www.roblox.com/games/4878988249"><strong>Game Link »</strong></a>
    <br />
    <br />
    <a href="https://discord.gg/RCc6ntue5j">Discord</a>
  </p>
</div>








## About The Macro
Free macro for Mighty Omega. My Discord for more info [Link](https://discord.gg/RCc6ntue5j)





<!-- GETTING STARTED -->
## Getting Started

First step - Install AutoHotKey



### Installation

1. Download Autohotkey at [this](https://www.autohotkey.com/)
2. Install Program

### Download Macro

• How to Download it? [this](https://youtu.be/Y02T8AiiJxw)

### Tutorial
   • More info [Discord](https://discord.gg/RCc6ntue5j)




<!-- <p align="right">(<a href="#top">back to top</a>)</p>



